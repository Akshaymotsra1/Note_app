package com.example.flutter_note

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
